AMS Pain Point Reference Package

วิธีใช้:
1. เปิดไฟล์ AWS_Present_All_PainPoint_Mapped_With_References.xlsx
2. ไปที่ sheet Pain Point Mapping เพื่อดู pain point และไฟล์อ้างอิงรายข้อ
3. ไปที่ sheet 05 Reference Files เพื่อดูรายชื่อไฟล์ต้นทางทั้งหมด
4. เปิดไฟล์จริงจากโฟลเดอร์ reference_files เมื่อลูกค้าขอดูหลักฐาน

หมายเหตุ:
- ไฟล์ลูกค้าเดิมถูก copy มาไว้ในแพ็กนี้เพื่อให้ตรวจสอบย้อนหลังได้
- ไฟล์ draw.io เป็นไฟล์แก้ไขได้ ใช้เปิดผ่าน diagrams.net/draw.io